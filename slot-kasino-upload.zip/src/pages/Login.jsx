import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';

export default function Login() {
  const [username, setUsername] = useState('');
  const navigate = useNavigate();

  const handleLogin = () => {
    const user = { username, credits: 100000 };
    localStorage.setItem('slot-user', JSON.stringify(user));
    navigate('/slot');
  };

  return (
    <div style={{ textAlign: 'center', marginTop: 100 }}>
      <h2>🔐 Masuk / Daftar</h2>
      <input value={username} onChange={e => setUsername(e.target.value)} placeholder="Nama Pengguna" />
      <br /><br />
      <button onClick={handleLogin}>Masuk</button>
    </div>
  );
}
