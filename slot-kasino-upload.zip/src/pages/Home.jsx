import React from 'react';
import { Link } from 'react-router-dom';

export default function Home() {
  return (
    <div style={{ textAlign: 'center', paddingTop: 50 }}>
      <h1>🎰 Kasino Edukatif</h1>
      <p>Selamat datang! Pilih permainan untuk belajar sambil bermain.</p>
      <Link to="/slot"><button>🎰 Slot Game</button></Link>
      <br /><br />
      <Link to="/login"><button>🔐 Login / Daftar</button></Link>
    </div>
  );
}
