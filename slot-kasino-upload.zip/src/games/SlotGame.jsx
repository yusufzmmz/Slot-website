import React, { useState, useEffect } from 'react';

const slotSymbols = ['🍒', '🍋', '🔔', '🍀', '💎', '7️⃣'];
const betOptions = [800, 1500, 5000, 10000, 100000];
const multipliers = [1, 2, 5, 8, 10, 20];

export default function SlotGame() {
  const stored = JSON.parse(localStorage.getItem("slot-user"));
  const [user, setUser] = useState(stored || { username: "", credits: 0 });
  const [reels, setReels] = useState(['🍒', '🍒', '🍒']);
  const [message, setMessage] = useState('');
  const [bet, setBet] = useState(10000);

  const spin = () => {
    if (user.credits < bet) {
      setMessage("💸 Saldo tidak cukup");
      return;
    }

    const newReels = [
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)],
      slotSymbols[Math.floor(Math.random() * slotSymbols.length)]
    ];

    let multiplier = 0;
    if (newReels.every(symbol => symbol === newReels[0])) {
      multiplier = multipliers[Math.floor(Math.random() * multipliers.length)];
    }

    const won = bet * multiplier;
    const finalCredit = user.credits - bet + won;
    const updated = { ...user, credits: finalCredit };
    localStorage.setItem("slot-user", JSON.stringify(updated));
    setUser(updated);
    setReels(newReels);

    setMessage(multiplier > 0 ? `🎉 Menang! x${multiplier} → +${won.toLocaleString()}` : "😢 Coba lagi!");
  };

  return (
    <div style={{ textAlign: 'center', padding: 40 }}>
      <h1>🎰 Slot Game</h1>
      <p>{user.username} | Kredit: {user.credits.toLocaleString()}</p>

      <div>
        {betOptions.map(b => (
          <button key={b} onClick={() => setBet(b)} style={{ margin: 4 }}>
            {b.toLocaleString()}
          </button>
        ))}
      </div>

      <div style={{ fontSize: 60, margin: 20 }}>{reels.join(" ")}</div>
      <button onClick={spin}>SPIN ({bet.toLocaleString()})</button>
      <p>{message}</p>
    </div>
  );
}
